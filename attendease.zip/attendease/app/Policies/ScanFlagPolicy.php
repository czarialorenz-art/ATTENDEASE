<?php

namespace App\Policies;

use App\Models\ScanFlag;
use App\Models\User;

class ScanFlagPolicy
{
    /** FR-ATT-11: only the class's teacher clears flags. */
    public function clear(User $user, ScanFlag $flag): bool
    {
        $class = $flag->scanLog->record->attendanceSession->schoolClass;

        return (int) $class->teacher_id === (int) $user->id;
    }
}
