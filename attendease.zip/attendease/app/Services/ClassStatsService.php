<?php

namespace App\Services;

use App\Models\SchoolClass;
use App\Models\AttendanceRecord;
use Illuminate\Support\Collection;

/**
 * FR-RPT-01: attendance summary per student.
 *
 * A session counts as held once its Time In stage has been opened. A held session with no
 * record for a student counts as an absence.
 */
class ClassStatsService
{
    /**
     * FR-RPT-01: sessions held within a date range (the semester by default).
     *
     * @param  array{0: string, 1: string}|null  $range  inclusive Y-m-d dates
     * @return array{rows: Collection, held: int}
     */
    public function termReport(SchoolClass $class, Collection $students, ?array $range = null): array
    {
        $range ??= [$class->semester_start->toDateString(), $class->semester_end->toDateString()];
        $attendance = $this->attendance($class, $students, $range);

        return [
            'rows' => $students->map(fn ($s) => ['student' => $s, ...$attendance[$s->id]])->values(),
            'held' => $attendance['_held'] ?? 0,
        ];
    }

    /** @param  array{0: string, 1: string}|null  $range  inclusive Y-m-d dates; null = all sessions */
    private function attendance(SchoolClass $class, Collection $students, ?array $range = null): array
    {
        $sessions = $class->attendanceSessions()
            ->whereNotNull('time_in_opened_at')
            ->when($range, fn ($q) => $q->whereDate('date', '>=', $range[0])->whereDate('date', '<=', $range[1]))
            ->pluck('id');

        $held = $sessions->count();

        $records = AttendanceRecord::whereIn('attendance_session_id', $sessions)
            ->whereIn('student_id', $students->pluck('id'))
            ->get()
            ->groupBy('student_id');

        $out = ['_held' => $held];

        foreach ($students as $student) {
            $mine = $records->get($student->id) ?? collect();
            $present = $mine->where('status', AttendanceRecord::PRESENT)->count();
            $late = $mine->where('status', AttendanceRecord::LATE)->count();
            $absent = max(0, $held - $present - $late);

            $out[$student->id] = [
                'present' => $present,
                'late' => $late,
                'absent' => $absent,
                'rate' => $held > 0 ? round(($present + $late) / $held * 100, 1) : null,
            ];
        }

        return $out;
    }
}
