<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;

class AttendanceRecord extends Model
{
    use HasFactory;

    public const PRESENT = 'present';
    public const LATE = 'late';
    public const ABSENT = 'absent';
    public const STATUSES = [self::PRESENT, self::LATE, self::ABSENT];

    public const SOURCE_QR = 'qr';
    public const SOURCE_MANUAL = 'manual';

    protected $fillable = ['attendance_session_id', 'student_id', 'status', 'time_in_at', 'time_out_at', 'source'];

    protected function casts(): array
    {
        return [
            'time_in_at' => 'datetime',
            'time_out_at' => 'datetime',
        ];
    }

    public function attendanceSession(): BelongsTo
    {
        return $this->belongsTo(AttendanceSession::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(User::class, 'student_id');
    }

    public function scanLogs(): HasMany
    {
        return $this->hasMany(ScanLog::class);
    }

    public function flags(): HasManyThrough
    {
        return $this->hasManyThrough(ScanFlag::class, ScanLog::class);
    }
}
