<?php

namespace App\Providers;

use App\Models\SchoolClass;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // {class} in routes binds to the "classes" table ("Class" is a reserved word in PHP).
        Route::model('class', SchoolClass::class);

        // Share the unread count with the top bar (FR-NOTIF-01).
        View::composer('components.layouts.app', function ($view) {
            $view->with('unreadCount', auth()->user()?->unreadNotifications()->count() ?? 0);
        });
    }
}
