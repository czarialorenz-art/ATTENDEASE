<?php

namespace App\Http\Controllers;

use App\Models\Enrollment;
use App\Models\SchoolClass;
use App\Services\ClassStatsService;
use App\Support\FileName;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\SimpleType\Jc;

/**
 * FR-RPT-01..03: attendance summary, teacher only.
 * The teacher picks the period: a day, a week (Mon–Sun), a month, or the whole semester.
 */
class ReportController extends Controller
{
    public const PERIODS = [
        'day' => 'Daily',
        'week' => 'Weekly',
        'month' => 'Monthly',
        'semester' => 'Semester',
    ];

    public function __construct(private ClassStatsService $stats) {}

    public function show(Request $request, SchoolClass $class)
    {
        $this->authorize('teach', $class);

        return view('reports.show', $this->data($request, $class));
    }

    public function pdf(Request $request, SchoolClass $class)
    {
        $this->authorize('teach', $class);
        $d = $this->data($request, $class);

        return Pdf::loadView('pdf.attendance-report', $d)
            ->setPaper('a4', 'landscape')
            ->download($d['fileName'].'.pdf');
    }

    public function docx(Request $request, SchoolClass $class)
    {
        $this->authorize('teach', $class);
        $d = $this->data($request, $class);

        $word = new PhpWord;
        $word->setDefaultFontName('Arial');
        $word->setDefaultFontSize(10);

        $section = $word->addSection(['orientation' => 'landscape', 'marginLeft' => 900, 'marginRight' => 900, 'marginTop' => 900, 'marginBottom' => 900]);
        $section->addText($d['schoolName'], ['bold' => true, 'size' => 14], ['alignment' => Jc::CENTER]);
        $section->addText($d['title'], ['bold' => true, 'size' => 12], ['alignment' => Jc::CENTER, 'spaceAfter' => 200]);

        foreach ($d['header'] as $label => $value) {
            $run = $section->addTextRun(['spaceAfter' => 0]);
            $run->addText($label.': ', ['bold' => true]);
            $run->addText((string) $value);
        }
        $section->addTextBreak();

        $word->addTableStyle('report', ['borderSize' => 6, 'borderColor' => '999999', 'cellMargin' => 60], ['bgColor' => 'E5E7EB']);
        $table = $section->addTable('report');
        $table->addRow(null, ['tblHeader' => true]);
        foreach (['#', 'Student No.', 'Name', 'Section', 'Present', 'Late', 'Absent', 'Rate'] as $h) {
            $table->addCell(null)->addText($h, ['bold' => true]);
        }

        foreach ($d['rows'] as $i => $row) {
            $table->addRow();
            $table->addCell(500)->addText((string) ($i + 1));
            $table->addCell(1800)->addText($row['student']->id_number);
            $table->addCell(3600)->addText($row['student']->name.($row['removed'] ? ' (removed)' : ''));
            $table->addCell(1400)->addText($row['student']->section ?: '—');
            $table->addCell(1100)->addText((string) $row['present']);
            $table->addCell(1100)->addText((string) $row['late']);
            $table->addCell(1100)->addText((string) $row['absent']);
            $table->addCell(1200)->addText($row['rate'] === null ? '—' : $row['rate'].'%');
        }

        $section->addTextBreak();
        $section->addText('Sessions held in this period: '.$d['held'], ['italic' => true]);

        $path = tempnam(sys_get_temp_dir(), 'rpt');
        IOFactory::createWriter($word, 'Word2007')->save($path);

        return response()->download($path, $d['fileName'].'.docx', [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ])->deleteFileAfterSend();
    }

    /**
     * Resolves the chosen period to an inclusive date range.
     *
     * @return array{period: string, date: CarbonImmutable, from: CarbonImmutable, to: CarbonImmutable}
     */
    private function range(Request $request, SchoolClass $class): array
    {
        $request->validate([
            'period' => ['nullable', Rule::in(array_keys(self::PERIODS))],
            'date' => ['nullable', 'date_format:Y-m-d'],
        ]);

        $period = $request->input('period', 'semester');
        $date = $request->filled('date')
            ? CarbonImmutable::createFromFormat('Y-m-d', $request->input('date'))->startOfDay()
            : CarbonImmutable::today();

        [$from, $to] = match ($period) {
            'day' => [$date, $date],
            'week' => [$date->startOfWeek(CarbonImmutable::MONDAY), $date->endOfWeek(CarbonImmutable::SUNDAY)->startOfDay()],
            'month' => [$date->startOfMonth(), $date->endOfMonth()->startOfDay()],
            default => [CarbonImmutable::parse($class->semester_start), CarbonImmutable::parse($class->semester_end)],
        };

        return compact('period', 'date', 'from', 'to');
    }

    private function data(Request $request, SchoolClass $class): array
    {
        ['period' => $period, 'date' => $date, 'from' => $from, 'to' => $to] = $this->range($request, $class);

        // Approved students plus removed ones, whose history is kept for reports (FR-CLS-06).
        $students = $class->students()
            ->wherePivotIn('status', [Enrollment::APPROVED, Enrollment::REMOVED])
            ->orderBy('name')
            ->get();

        $report = $this->stats->termReport($class, $students, [$from->toDateString(), $to->toDateString()]);

        $rows = $report['rows']->map(fn ($r) => [...$r, 'removed' => $r['student']->pivot->status === Enrollment::REMOVED]);

        $periodLabel = match ($period) {
            'day' => $from->format('l, M j, Y'),
            'week' => 'Week of '.$from->format('M j').' – '.$to->format('M j, Y'),
            'month' => $from->format('F Y'),
            default => $class->semester.' semester ('.$from->format('M j, Y').' – '.$to->format('M j, Y').')',
        };

        $safe = fn ($v) => FileName::safe($v);
        $suffix = match ($period) {
            'day' => $from->format('Y-m-d'),
            'week' => 'Week_'.$from->format('Y-m-d'),
            'month' => $from->format('Y-m'),
            default => $safe($class->school_term),
        };

        return [
            'class' => $class,
            'schoolName' => config('app.school_name'),
            'title' => self::PERIODS[$period].' Attendance Summary',
            'period' => $period,
            'periods' => self::PERIODS,
            'date' => $date,
            'query' => ['period' => $period, 'date' => $date->toDateString()],
            'rows' => $rows,
            'held' => $report['held'],
            'header' => [
                'Subject' => $class->subject,
                'Section' => $class->section,
                'School term' => $class->school_term,
                'Semester' => $class->semester,
                'Period' => $periodLabel,
                'Teacher' => $class->teacher->name,
                'Generated' => now()->format('M j, Y g:i A'),
            ],
            'fileName' => $safe($class->subject).'_'.$safe($class->section).'_Attendance_'.$suffix,
        ];
    }
}
