<?php

namespace App\Http\Controllers;

use App\Models\AttendanceSession;
use App\Models\Enrollment;
use Illuminate\Http\Request;

/** FR-CLS-08 plus the "today" lists from section 10. */
class DashboardController extends Controller
{
    public function __invoke(Request $request)
    {
        $user = $request->user();

        $teaching = $user->taughtClasses()
            ->withCount(['enrollments as pending_count' => fn ($q) => $q->where('status', Enrollment::PENDING)])
            ->withCount(['enrollments as student_count' => fn ($q) => $q->where('status', Enrollment::APPROVED)])
            ->orderByDesc('created_at')
            ->get();

        $enrolled = $user->enrollments()
            ->whereIn('status', [Enrollment::APPROVED, Enrollment::PENDING])
            ->with('schoolClass.teacher')
            ->orderByRaw("case when status = 'approved' then 0 else 1 end")
            ->latest()
            ->get();

        $todaySessions = AttendanceSession::whereIn('class_id', $teaching->pluck('id'))
            ->whereDate('date', now()->toDateString())
            ->with('schoolClass')
            ->orderBy('created_at')
            ->get();

        return view('dashboard', compact('teaching', 'enrolled', 'todaySessions'));
    }
}
