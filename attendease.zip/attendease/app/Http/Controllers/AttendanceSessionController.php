<?php

namespace App\Http\Controllers;

use App\Models\AttendanceRecord;
use App\Models\AttendanceSession;
use App\Models\ScanFlag;
use App\Models\SchoolClass;
use App\Models\User;
use App\Services\AttendanceService;
use App\Services\QrTokenService;
use chillerlan\QRCode\QRCode;
use chillerlan\QRCode\QROptions;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AttendanceSessionController extends Controller
{
    public function __construct(private AttendanceService $attendance) {}

    public function index(SchoolClass $class)
    {
        $this->authorize('teach', $class);

        return view('sessions.index', [
            'class' => $class,
            'sessions' => $class->attendanceSessions()->withCount('records')->latest('date')->latest()->paginate(20),
        ]);
    }

    /** FR-ATT-01 */
    public function store(Request $request, SchoolClass $class)
    {
        $this->authorize('teach', $class);

        $data = $request->validate([
            'date' => ['required', 'date'],
            'title' => ['nullable', 'string', 'max:255'],
            'grace_minutes' => ['nullable', 'integer', 'min:0', 'max:1440'],
        ]);
        $data['grace_minutes'] ??= 15;

        $session = $class->attendanceSessions()->create($data);

        return redirect()->route('sessions.show', $session)->with('status', 'Session created.');
    }

    /** FR-ATT-11/12: records, flags and manual edits. */
    public function show(AttendanceSession $attendanceSession)
    {
        $this->authorize('manage', $attendanceSession);
        $session = $attendanceSession->load('schoolClass');

        $records = $session->records()->with(['scanLogs.flags.clearedBy'])->get()->keyBy('student_id');
        $students = $session->schoolClass->approvedStudents()->orderBy('name')->get();

        // Include removed students who still have a record here (FR-CLS-06 keeps their history).
        $extra = User::whereIn('id', $records->keys()->diff($students->pluck('id')))->orderBy('name')->get();

        $flags = ScanFlag::whereHas('scanLog.record', fn ($q) => $q->where('attendance_session_id', $session->id))
            ->with(['scanLog.record.student', 'clearedBy'])
            ->orderByRaw('cleared_at is not null')
            ->latest()
            ->get();

        return view('sessions.show', [
            'session' => $session,
            'class' => $session->schoolClass,
            'students' => $students->concat($extra),
            'records' => $records,
            'flags' => $flags,
        ]);
    }

    /** FR-ATT-01: title and grace period can change at any time. */
    public function update(Request $request, AttendanceSession $attendanceSession)
    {
        $this->authorize('manage', $attendanceSession);

        $data = $request->validate([
            'title' => ['nullable', 'string', 'max:255'],
            'grace_minutes' => ['required', 'integer', 'min:0', 'max:1440'],
        ]);

        $attendanceSession->update(['title' => $data['title'] ?? null]);

        if ((int) $data['grace_minutes'] !== $attendanceSession->grace_minutes) {
            $this->attendance->updateGrace($attendanceSession, (int) $data['grace_minutes']);
        }

        return back()->with('status', 'Session updated.');
    }

    public function open(AttendanceSession $attendanceSession, string $stage)
    {
        $this->authorize('manage', $attendanceSession);

        if ($error = $this->attendance->openStage($attendanceSession, $stage)) {
            return back()->withErrors(['stage' => $error]);
        }

        return redirect()->route('sessions.live', $attendanceSession);
    }

    public function close(AttendanceSession $attendanceSession, string $stage)
    {
        $this->authorize('manage', $attendanceSession);

        if ($error = $this->attendance->closeStage($attendanceSession, $stage)) {
            return back()->withErrors(['stage' => $error]);
        }

        return redirect()->route('sessions.show', $attendanceSession)
            ->with('status', AttendanceSession::stageLabel($stage).' closed.');
    }

    /** FR-ATT-04: full-screen rotating QR. */
    public function live(AttendanceSession $attendanceSession)
    {
        $this->authorize('manage', $attendanceSession);

        return view('sessions.live', [
            'session' => $attendanceSession->load('schoolClass'),
            'state' => $this->state($attendanceSession),
        ]);
    }

    /** Polled every 5 seconds by the live screen. */
    public function liveState(AttendanceSession $attendanceSession)
    {
        $this->authorize('manage', $attendanceSession);

        return response()->json($this->state($attendanceSession->fresh()));
    }

    private function state(AttendanceSession $session): array
    {
        $stage = $session->openStage();
        $qr = null;
        $url = null;

        if ($stage && $session->isToday()) {
            $tokens = app(QrTokenService::class);
            $url = route('scan', ['t' => $tokens->issue($session, $stage)]);
            $qr = (new QRCode(new QROptions(['outputBase64' => true, 'scale' => 10, 'addQuietzone' => true])))->render($url);
        }

        $column = ($stage ?? AttendanceSession::TIME_IN).'_at';

        return [
            'stage' => $stage,
            'stage_label' => $stage ? AttendanceSession::stageLabel($stage) : null,
            'qr' => $qr,
            'url' => $url,
            'rotates_in' => app(QrTokenService::class)->secondsUntilRotation(),
            'count' => $session->records()->whereNotNull($column)->count(),
            'total' => $session->schoolClass->approvedStudents()->count(),
            'flags' => ScanFlag::whereNull('cleared_at')
                ->whereHas('scanLog.record', fn ($q) => $q->where('attendance_session_id', $session->id))->count(),
        ];
    }

    /** FR-ATT-12 */
    public function manual(Request $request, AttendanceSession $attendanceSession)
    {
        $this->authorize('manage', $attendanceSession);
        $class = $attendanceSession->schoolClass;

        $data = $request->validate([
            'student_id' => ['required', 'integer'],
            'status' => ['required', Rule::in(AttendanceRecord::STATUSES)],
        ]);

        $student = $class->students()
            ->where('users.id', $data['student_id'])
            ->first();

        abort_unless($student && ($student->pivot->status === 'approved'
            || $attendanceSession->records()->where('student_id', $student->id)->exists()), 422, 'That student is not in this class.');

        $this->attendance->setManualStatus($attendanceSession, $student, $data['status']);

        return back()->with('status', $student->name.' marked '.ucfirst($data['status']).'.');
    }

    /** FR-ATT-11: a cleared flag stays in the log. */
    public function clearFlag(Request $request, ScanFlag $scanFlag)
    {
        $this->authorize('clear', $scanFlag);

        if (! $scanFlag->isCleared()) {
            $scanFlag->update(['cleared_by' => $request->user()->id, 'cleared_at' => now()]);
        }

        return back()->with('status', 'Flag cleared.');
    }
}
