
<?php if(filled($student->section)): ?>
    <span class="badge-neutral font-semibold" title="Section">Section <?php echo e($student->section); ?></span>
<?php else: ?>
    <span class="badge border border-dashed border-slate-300 font-normal text-slate-400" title="The student hasn't set a section in their profile">No section</span>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/classes/_section-badge.blade.php ENDPATH**/ ?>