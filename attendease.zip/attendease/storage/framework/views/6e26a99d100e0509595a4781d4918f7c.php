<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Scan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Scan']); ?>
    <div class="mx-auto max-w-md">
        <div class="card text-center">
            <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mx-auto mb-3 grid h-16 w-16 place-items-center rounded-full text-3xl', 'bg-emerald-100 text-emerald-700' => $ok, 'bg-red-100 text-red-700' => ! $ok]); ?>"><?php echo e($ok ? '✓' : '!'); ?></div>
            <h1 class="text-lg font-bold"><?php echo e($title); ?></h1>
            <p class="mt-1 text-sm text-slate-600"><?php echo e($message); ?></p>
            <?php if (! ($ok)): ?>
                <a href="<?php echo e(route('scanner')); ?>" class="btn-primary mt-6 w-full">Scan again</a>
            <?php endif; ?>
            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['btn-secondary w-full', 'mt-6' => $ok, 'mt-2' => ! $ok]); ?>">Go to dashboard</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/scan/result.blade.php ENDPATH**/ ?>