<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $class->subject.' report']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->subject.' report')]); ?>
    <?php if (isset($component)) { $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.class-nav','data' => ['class' => $class,'active' => 'report']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('class-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class),'active' => 'report']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $attributes = $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $component = $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>

    
    <form method="GET" class="card mb-5 flex flex-col gap-4 sm:flex-row sm:items-end" id="period-form">
        <fieldset>
            <legend class="label">Report period</legend>
            <div class="inline-flex flex-wrap rounded-lg border border-slate-300 bg-white p-1">
                <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="cursor-pointer">
                        <input type="radio" name="period" value="<?php echo e($key); ?>" class="peer sr-only" <?php if($period === $key): echo 'checked'; endif; ?>>
                        <span class="block rounded-md px-3 py-1.5 text-sm font-medium text-slate-600 peer-checked:bg-brand-600 peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-brand-600">
                            <?php echo e(['day' => 'Day', 'week' => 'Week', 'month' => 'Month', 'semester' => 'Semester'][$key]); ?>

                        </span>
                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </fieldset>

        <div id="date-field" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['hidden' => $period === 'semester']); ?>">
            <label for="date" class="label" id="date-label">
                <?php echo e(['day' => 'Date', 'week' => 'Any day in the week', 'month' => 'Any day in the month'][$period] ?? 'Date'); ?>

            </label>
            <input type="date" id="date" name="date" value="<?php echo e($date->toDateString()); ?>" class="input">
        </div>

        <button class="btn-primary sm:ml-auto">Show report</button>
    </form>

    <div class="card">
        <div class="mb-4 flex flex-wrap items-start justify-between gap-3">
            <div>
                <div class="text-sm font-semibold text-brand-700"><?php echo e($schoolName); ?></div>
                <h2 class="text-lg font-bold"><?php echo e($title); ?></h2>
                <dl class="mt-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 text-sm">
                    <?php $__currentLoopData = $header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <dt class="text-slate-500"><?php echo e($label); ?></dt><dd><?php echo e($value); ?></dd>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </dl>
            </div>
            <div class="flex gap-2">
                <a href="<?php echo e(route('reports.docx', [$class, ...$query])); ?>" class="btn-secondary">Download .docx</a>
                <a href="<?php echo e(route('reports.pdf', [$class, ...$query])); ?>" class="btn-primary">Download PDF</a>
            </div>
        </div>

        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>#</th><th>Student No.</th><th>Name</th><th>Section</th><th class="text-center">Present</th><th class="text-center">Late</th><th class="text-center">Absent</th><th class="text-center">Rate</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td class="font-mono text-xs"><?php echo e($r['student']->id_number); ?></td>
                            <td><?php echo e($r['student']->name); ?> <?php if($r['removed']): ?><span class="badge-removed">removed</span><?php endif; ?></td>
                            <td class="whitespace-nowrap"><?php echo e($r['student']->section ?: '—'); ?></td>
                            <td class="text-center"><?php echo e($r['present']); ?></td>
                            <td class="text-center"><?php echo e($r['late']); ?></td>
                            <td class="text-center"><?php echo e($r['absent']); ?></td>
                            <td class="text-center font-semibold"><?php echo e($r['rate'] === null ? '—' : $r['rate'].'%'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="8" class="py-6 text-center text-slate-500">No students.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <p class="mt-2 text-xs text-slate-500">
            Out of <?php echo e($held); ?> <?php echo e(\Illuminate\Support\Str::plural('session', $held)); ?> held in this period.
            <?php if($held === 0): ?> No sessions were held, so rates show as —. <?php endif; ?>
            Rate = (Present + Late) ÷ sessions held.
        </p>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        (() => {
            const labels = { day: 'Date', week: 'Any day in the week', month: 'Any day in the month' };
            const form = document.getElementById('period-form');
            form.addEventListener('change', e => {
                if (e.target.name !== 'period') return;
                const p = e.target.value;
                document.getElementById('date-field').classList.toggle('hidden', p === 'semester');
                if (labels[p]) document.getElementById('date-label').textContent = labels[p];
            });
        })();
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/reports/show.blade.php ENDPATH**/ ?>