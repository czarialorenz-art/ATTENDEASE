<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\MTQ APP\attendease\resources\views\vendor\mail\text/button.blade.php ENDPATH**/ ?>