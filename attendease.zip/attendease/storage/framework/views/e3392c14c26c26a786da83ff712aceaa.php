<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'label', 'type' => 'text', 'value' => null, 'help' => null, 'required' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'label', 'type' => 'text', 'value' => null, 'help' => null, 'required' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php ($id = 'f_'.str_replace(['[', ']', '.'], '_', $name)); ?>
<div <?php echo e($attributes->only('class')); ?>>
    <label for="<?php echo e($id); ?>" class="label"><?php echo e($label); ?><?php if($required): ?> <span class="text-red-600">*</span><?php endif; ?></label>
    <?php if($type === 'select'): ?>
        <select id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input', 'input-error' => $errors->has($name)]); ?>" <?php echo e($attributes->except('class')); ?> <?php if($required): echo 'required'; endif; ?>>
            <?php echo e($slot); ?>

        </select>
    <?php elseif($type === 'textarea'): ?>
        <textarea id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input', 'input-error' => $errors->has($name)]); ?>" <?php echo e($attributes->except('class')); ?> <?php if($required): echo 'required'; endif; ?>><?php echo e(old($name, $value)); ?></textarea>
    <?php else: ?>
        <input id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" type="<?php echo e($type); ?>"
            <?php if($type !== 'password' && $type !== 'file'): ?> value="<?php echo e(old($name, $value)); ?>" <?php endif; ?>
            class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input', 'input-error' => $errors->has($name)]); ?>" <?php echo e($attributes->except('class')); ?> <?php if($required): echo 'required'; endif; ?>>
    <?php endif; ?>
    <?php if($help): ?><p class="help"><?php echo e($help); ?></p><?php endif; ?>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\MTQ APP\attendease\resources\views/components/field.blade.php ENDPATH**/ ?>