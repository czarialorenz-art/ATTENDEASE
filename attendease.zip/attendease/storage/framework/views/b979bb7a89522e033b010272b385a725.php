<?php echo e($slot); ?>

<?php /**PATH C:\MTQ APP\attendease\resources\views\vendor\mail\text/footer.blade.php ENDPATH**/ ?>