<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $class->subject]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->subject)]); ?>
    <div class="mb-5">
        <h1 class="h1"><?php echo e($class->subject); ?> <span class="font-medium text-slate-500">· <?php echo e($class->section); ?></span></h1>
        <p class="text-sm text-slate-500"><?php echo e($class->teacher->name); ?> · <?php echo e($class->year_level); ?> · <?php echo e($class->school_term); ?> · <?php echo e($class->semester); ?> sem</p>
        <?php if($class->schedules->isNotEmpty()): ?>
            <p class="mt-1 text-sm text-slate-500">
                <?php $__currentLoopData = $class->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($row->dayName()); ?> <?php echo e(substr($row->start_time, 0, 5)); ?>–<?php echo e(substr($row->end_time, 0, 5)); ?><?php if($row->room): ?> (<?php echo e($row->room); ?>)<?php endif; ?><?php echo e($loop->last ? '' : ' · '); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        <?php endif; ?>
    </div>

    
    <div class="card">
        <div class="mb-4 flex flex-wrap items-center justify-between gap-2">
            <h2 class="h2">My attendance this semester</h2>
            <a href="<?php echo e(route('attendance.history', ['class_id' => $class->id])); ?>" class="text-sm text-brand-600 hover:underline">Full history →</a>
        </div>

        <dl class="grid grid-cols-2 gap-3 text-center sm:grid-cols-4">
            <div class="rounded-lg bg-emerald-50 p-3"><dt class="text-xs text-emerald-700">Present</dt><dd class="text-2xl font-bold text-emerald-800"><?php echo e($mine['present']); ?></dd></div>
            <div class="rounded-lg bg-amber-50 p-3"><dt class="text-xs text-amber-700">Late</dt><dd class="text-2xl font-bold text-amber-800"><?php echo e($mine['late']); ?></dd></div>
            <div class="rounded-lg bg-red-50 p-3"><dt class="text-xs text-red-700">Absent</dt><dd class="text-2xl font-bold text-red-800"><?php echo e($mine['absent']); ?></dd></div>
            <div class="rounded-lg bg-slate-50 p-3"><dt class="text-xs text-slate-500">Attendance rate</dt><dd class="text-2xl font-bold"><?php echo e($mine['rate'] === null ? '—' : $mine['rate'].'%'); ?></dd></div>
        </dl>
        <p class="mt-3 text-xs text-slate-500">Out of <?php echo e($held); ?> <?php echo e(\Illuminate\Support\Str::plural('session', $held)); ?> held so far this semester.</p>

        <a href="<?php echo e(route('scanner')); ?>" class="btn-primary mt-4 w-full sm:w-auto">Scan attendance QR</a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/classes/student.blade.php ENDPATH**/ ?>