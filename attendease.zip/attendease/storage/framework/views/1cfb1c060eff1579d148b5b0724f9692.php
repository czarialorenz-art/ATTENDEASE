<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Notifications']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Notifications']); ?>
    <div class="mx-auto max-w-2xl">
        <div class="mb-5 flex items-center justify-between gap-3">
            <h1 class="h1">Notifications</h1>
            <?php if(auth()->user()->unreadNotifications()->exists()): ?>
                <form method="POST" action="<?php echo e(route('notifications.read-all')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn-secondary btn-sm">Mark all as read</button>
                </form>
            <?php endif; ?>
        </div>

        <div class="card divide-y divide-slate-100 p-0 sm:p-0">
            <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex gap-3 px-4 py-3', 'bg-brand-50/60' => ! $n->read_at]); ?>">
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-1.5 h-2 w-2 shrink-0 rounded-full', 'bg-brand-600' => ! $n->read_at, 'bg-transparent' => $n->read_at]); ?>"></span>
                    <div class="min-w-0 flex-1">
                        <form method="POST" action="<?php echo e(route('notifications.read', $n->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="follow" value="1">
                            <button class="text-left">
                                <div class="font-medium text-slate-900"><?php echo e($n->data['title'] ?? 'Notification'); ?></div>
                                <div class="text-sm text-slate-600"><?php echo e($n->data['message'] ?? ''); ?></div>
                            </button>
                        </form>
                        <div class="mt-1 flex items-center gap-3 text-xs text-slate-500">
                            <span><?php echo e($n->created_at->diffForHumans()); ?></span>
                            <?php if (! ($n->read_at)): ?>
                                <form method="POST" action="<?php echo e(route('notifications.read', $n->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="font-medium text-brand-600 hover:underline">Mark as read</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="px-4 py-8 text-center text-sm text-slate-500">No notifications yet.</p>
            <?php endif; ?>
        </div>

        <div class="mt-4"><?php echo e($notifications->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/notifications/index.blade.php ENDPATH**/ ?>