<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $class->subject]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->subject)]); ?>
    <?php if (isset($component)) { $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.class-nav','data' => ['class' => $class,'active' => 'overview']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('class-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class),'active' => 'overview']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $attributes = $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $component = $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>

    <div class="grid gap-6 lg:grid-cols-3">
        <div class="card lg:col-span-1">
            <div class="text-xs font-semibold tracking-wide text-slate-500 uppercase">Class code</div>
            <div class="mt-2 flex items-center gap-2">
                <span id="class-code" class="font-mono text-3xl font-bold tracking-[0.2em] text-brand-700"><?php echo e($class->code); ?></span>
                <button type="button" class="btn-secondary btn-sm" data-copy="#class-code">Copy</button>
            </div>
            <p class="mt-2 text-sm text-slate-500">Students enter this on their dashboard to ask to join.</p>

            <dl class="mt-5 grid grid-cols-2 gap-3 text-center">
                <div class="rounded-lg bg-slate-50 p-3"><dt class="text-xs text-slate-500">Students</dt><dd class="text-xl font-bold"><?php echo e($studentCount); ?></dd></div>
                <a href="<?php echo e(route('classes.students', $class)); ?>" class="rounded-lg bg-amber-50 p-3 hover:bg-amber-100"><dt class="text-xs text-amber-700">Pending</dt><dd class="text-xl font-bold text-amber-800"><?php echo e($pendingCount); ?></dd></a>
            </dl>
        </div>

        <div class="card lg:col-span-2">
            <div class="mb-3 flex items-center justify-between">
                <h2 class="h2">Recent sessions</h2>
                <a href="<?php echo e(route('sessions.index', $class)); ?>" class="btn-primary btn-sm">+ New session</a>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $recentSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('sessions.show', $s)); ?>" class="-mx-2 flex items-center justify-between rounded-lg px-2 py-2 hover:bg-slate-50">
                    <span><span class="font-medium"><?php echo e($s->date->format('D, M j, Y')); ?></span> <span class="text-sm text-slate-500"><?php echo e($s->title); ?></span></span>
                    <span class="text-xs text-slate-500">
                        <?php if($s->openStage()): ?> <span class="badge-approved"><?php echo e(\App\Models\AttendanceSession::stageLabel($s->openStage())); ?> open</span>
                        <?php elseif($s->time_out_closed_at): ?> Completed <?php elseif($s->time_in_opened_at): ?> In progress <?php else: ?> Not started <?php endif; ?>
                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">No sessions yet.</p>
            <?php endif; ?>

            <h2 class="h2 mt-6 mb-2">Weekly schedule</h2>
            <?php $__empty_1 = true; $__currentLoopData = $class->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="text-sm"><?php echo e($row->dayName()); ?> · <?php echo e(substr($row->start_time, 0, 5)); ?>–<?php echo e(substr($row->end_time, 0, 5)); ?> <?php if($row->room): ?> · <?php echo e($row->room); ?> <?php endif; ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">No schedule set. <a href="<?php echo e(route('classes.edit', $class)); ?>" class="text-brand-600 hover:underline">Add one</a>.</p>
            <?php endif; ?>
            <p class="mt-2 text-sm text-slate-500">
                Location check: <?php echo e($class->hasLocation() ? 'on, '.$class->radius_m.' m radius' : 'off (no classroom location set)'); ?>

            </p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/classes/show.blade.php ENDPATH**/ ?>