<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
    <div class="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
            <h1 class="h1">Hi, <?php echo e(\Illuminate\Support\Str::before(auth()->user()->name, ' ') ?: auth()->user()->name); ?></h1>
            <p class="text-sm text-slate-500"><?php echo e(now()->format('l, F j, Y')); ?></p>
        </div>
        <a href="<?php echo e(route('classes.create')); ?>" class="btn-primary">+ Create a class</a>
    </div>

    
    <form method="POST" action="<?php echo e(route('classes.join')); ?>" class="card mb-6 flex flex-col gap-3 sm:flex-row sm:items-end" novalidate>
        <?php echo csrf_field(); ?>
        <div class="flex-1">
            <label for="code" class="label">Join a class</label>
            <input id="code" name="code" value="<?php echo e(old('code')); ?>" maxlength="8" autocapitalize="characters" autocomplete="off"
                placeholder="Enter class code" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['input font-mono tracking-widest uppercase', 'input-error' => $errors->has('code')]); ?>">
            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn-primary sm:w-40">Ask to join</button>
    </form>

    <div class="grid gap-6 lg:grid-cols-2">
        
        <section class="space-y-6">
            <?php if($todaySessions->isNotEmpty()): ?>
                <div class="card">
                    <h2 class="h2 mb-3">Today's sessions</h2>
                    <ul class="divide-y divide-slate-100">
                        <?php $__currentLoopData = $todaySessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-center justify-between gap-3 py-2">
                                <div class="min-w-0">
                                    <div class="truncate font-medium"><?php echo e($s->schoolClass->label()); ?></div>
                                    <div class="text-xs text-slate-500"><?php echo e($s->title ?: 'Attendance'); ?> ·
                                        <?php if($s->openStage()): ?> <span class="font-semibold text-emerald-700"><?php echo e(\App\Models\AttendanceSession::stageLabel($s->openStage())); ?> open</span>
                                        <?php elseif($s->time_out_closed_at): ?> Completed
                                        <?php else: ?> Not started <?php endif; ?>
                                    </div>
                                </div>
                                <a href="<?php echo e($s->openStage() ? route('sessions.live', $s) : route('sessions.show', $s)); ?>" class="btn-secondary btn-sm"><?php echo e($s->openStage() ? 'Show QR' : 'Open'); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card">
                <h2 class="h2 mb-3">Classes I teach</h2>
                <?php $__empty_1 = true; $__currentLoopData = $teaching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('classes.show', $c)); ?>" class="-mx-2 flex items-center justify-between gap-3 rounded-lg px-2 py-2.5 hover:bg-slate-50">
                        <div class="min-w-0">
                            <div class="truncate font-medium"><?php echo e($c->subject); ?> · <?php echo e($c->section); ?></div>
                            <div class="text-xs text-slate-500"><?php echo e($c->school_term); ?> · <?php echo e($c->semester); ?> sem · <?php echo e($c->student_count); ?> <?php echo e(\Illuminate\Support\Str::plural('student', $c->student_count)); ?> · code <span class="font-mono"><?php echo e($c->code); ?></span></div>
                        </div>
                        <?php if($c->pending_count): ?>
                            <span class="badge-pending shrink-0"><?php echo e($c->pending_count); ?> pending</span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-slate-500">You don't teach any classes yet. Create one to get a join code for your students.</p>
                <?php endif; ?>
            </div>
        </section>

        
        <section class="space-y-6">
            <?php if($enrolled->where('status', 'approved')->isNotEmpty()): ?>
                <a href="<?php echo e(route('scanner')); ?>" class="card flex items-center gap-4 border-brand-100 bg-brand-50 hover:bg-brand-100">
                    <span class="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brand-600 text-white">
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 7V5a1 1 0 011-1h2M17 4h2a1 1 0 011 1v2M20 17v2a1 1 0 01-1 1h-2M7 20H5a1 1 0 01-1-1v-2M8 8h3v3H8zM13 13h3v3h-3zM13 8h3M8 13v3"/></svg>
                    </span>
                    <span>
                        <span class="block font-semibold text-brand-800">Scan attendance QR</span>
                        <span class="block text-sm text-slate-600">Open the camera and scan the code on your teacher's screen.</span>
                    </span>
                </a>
            <?php endif; ?>

            <div class="card">
                <h2 class="h2 mb-3">Classes I'm in</h2>
                <?php $__empty_1 = true; $__currentLoopData = $enrolled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php ($approved = $e->status === 'approved'); ?>
                    <<?php echo e($approved ? 'a' : 'div'); ?> <?php if($approved): ?> href="<?php echo e(route('classes.show', $e->schoolClass)); ?>" <?php endif; ?>
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses(['-mx-2 flex items-center justify-between gap-3 rounded-lg px-2 py-2.5', 'hover:bg-slate-50' => $approved]); ?>">
                        <div class="min-w-0">
                            <div class="truncate font-medium"><?php echo e($e->schoolClass->subject); ?> · <?php echo e($e->schoolClass->section); ?></div>
                            <div class="text-xs text-slate-500"><?php echo e($e->schoolClass->teacher->name); ?> · <?php echo e($e->schoolClass->school_term); ?></div>
                        </div>
                        <?php if (! ($approved)): ?><span class="badge-pending shrink-0">Waiting for approval</span><?php endif; ?>
                    </<?php echo e($approved ? 'a' : 'div'); ?>>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-slate-500">You haven't joined any classes. Enter the code your teacher gives you above.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/dashboard.blade.php ENDPATH**/ ?>