<?php use \App\Models\AttendanceSession as S; ?>
<?php use \App\Models\ScanFlag; ?>
<?php
    $open = $session->openStage();
    $today = $session->isToday();
?>
<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Session '.$session->date->format('M j')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Session '.$session->date->format('M j'))]); ?>
    <?php if (isset($component)) { $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.class-nav','data' => ['class' => $class,'active' => 'sessions']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('class-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class),'active' => 'sessions']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $attributes = $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $component = $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>

    <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
            <h2 class="text-lg font-bold"><?php echo e($session->date->format('l, F j, Y')); ?> <?php if($session->title): ?><span class="font-normal text-slate-500">· <?php echo e($session->title); ?></span><?php endif; ?></h2>
            <p class="text-sm text-slate-500">
                Time In: <?php echo e($session->time_in_opened_at?->format('g:i A') ?? 'not opened'); ?><?php if($session->time_in_closed_at): ?>–<?php echo e($session->time_in_closed_at->format('g:i A')); ?><?php endif; ?>
                · Time Out: <?php echo e($session->time_out_opened_at?->format('g:i A') ?? 'not opened'); ?><?php if($session->time_out_closed_at): ?>–<?php echo e($session->time_out_closed_at->format('g:i A')); ?><?php endif; ?>
            </p>
        </div>

        
        <div class="flex flex-wrap gap-2">
            <?php if($open): ?>
                <a href="<?php echo e(route('sessions.live', $session)); ?>" class="btn-primary">Show QR (<?php echo e(S::stageLabel($open)); ?>)</a>
                <form method="POST" action="<?php echo e(route('sessions.close', [$session, $open])); ?>"
                      <?php if($open === S::TIME_OUT): ?> data-confirm="Close Time Out? Students missing a Time In or Time Out will be marked Absent." <?php endif; ?>>
                    <?php echo csrf_field(); ?><button class="btn-danger">Close <?php echo e(S::stageLabel($open)); ?></button>
                </form>
            <?php elseif(! $session->time_out_closed_at): ?>
                <?php if(! $session->time_out_opened_at): ?>
                    <form method="POST" action="<?php echo e(route('sessions.open', [$session, S::TIME_IN])); ?>"><?php echo csrf_field(); ?>
                        <button class="<?php echo e($session->time_in_opened_at ? 'btn-secondary' : 'btn-primary'); ?>" <?php if(! $today): echo 'disabled'; endif; ?>><?php echo e($session->time_in_opened_at ? 'Reopen Time In' : 'Open Time In'); ?></button>
                    </form>
                <?php endif; ?>
                <?php if($session->time_in_closed_at): ?>
                    <form method="POST" action="<?php echo e(route('sessions.open', [$session, S::TIME_OUT])); ?>"><?php echo csrf_field(); ?>
                        <button class="btn-primary" <?php if(! $today): echo 'disabled'; endif; ?>>Open Time Out</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <span class="badge-neutral">Completed</span>
            <?php endif; ?>
        </div>
    </div>
    <?php if (! ($today || $session->time_out_closed_at)): ?>
        <p class="mb-4 rounded-lg bg-amber-50 px-4 py-2 text-sm text-amber-800">Stages can only be opened on <?php echo e($session->date->format('M j, Y')); ?> (Asia/Manila).</p>
    <?php endif; ?>

    <div class="grid gap-6 lg:grid-cols-3">
        <div class="space-y-6 lg:col-span-2">
            
            <div class="card">
                <h2 class="h2 mb-3">Attendance</h2>
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th>Student</th><th>Status</th><th>Time In</th><th>Time Out</th><th>Set status</th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php ($r = $records->get($student->id)); ?>
                                <?php ($flagCount = $r ? $r->scanLogs->flatMap->flags->whereNull('cleared_at')->count() : 0); ?>
                                <tr>
                                    <td>
                                        <div class="font-medium whitespace-nowrap"><?php echo e($student->name); ?></div>
                                        <div class="font-mono text-xs text-slate-500"><?php echo e($student->id_number); ?></div>
                                    </td>
                                    <td class="whitespace-nowrap">
                                        <?php if($r): ?><span class="badge-<?php echo e($r->status); ?>"><?php echo e(ucfirst($r->status)); ?></span>
                                            <?php if($r->source === 'manual'): ?><span class="badge-neutral">manual</span><?php endif; ?>
                                            <?php if($flagCount): ?><span class="badge-flag" title="Unreviewed flags">⚑ <?php echo e($flagCount); ?></span><?php endif; ?>
                                        <?php else: ?> <span class="text-slate-400">—</span> <?php endif; ?>
                                    </td>
                                    <td class="whitespace-nowrap"><?php echo e($r?->time_in_at?->format('g:i:s A') ?? '—'); ?></td>
                                    <td class="whitespace-nowrap"><?php echo e($r?->time_out_at?->format('g:i:s A') ?? '—'); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('sessions.manual', $session)); ?>" class="flex gap-1">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
                                            <select name="status" class="input py-1 text-xs" aria-label="Status for <?php echo e($student->name); ?>">
                                                <?php $__currentLoopData = \App\Models\AttendanceRecord::STATUSES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($st); ?>" <?php if($r?->status === $st): echo 'selected'; endif; ?>><?php echo e(ucfirst($st)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button class="btn-secondary btn-sm">Set</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="py-6 text-center text-slate-500">No approved students yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            
            <div class="card">
                <h2 class="h2 mb-1">Flagged scans</h2>
                <p class="mb-3 text-sm text-slate-500">Flags never block a scan. Review each one and clear it if it's fine.</p>
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th>Student</th><th>Reason</th><th>Stage</th><th>Distance</th><th>IP</th><th>Time</th><th></th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $flags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="<?php echo \Illuminate\Support\Arr::toCssClasses(['opacity-60' => $f->isCleared()]); ?>">
                                    <td class="whitespace-nowrap"><?php echo e($f->scanLog->record->student->name); ?></td>
                                    <td><span class="badge-flag"><?php echo e($f->code); ?></span><div class="text-xs text-slate-500"><?php echo e(ScanFlag::DESCRIPTIONS[$f->code] ?? ''); ?></div></td>
                                    <td class="whitespace-nowrap"><?php echo e(S::stageLabel($f->scanLog->stage)); ?></td>
                                    <td class="whitespace-nowrap">
                                        <?php echo e($f->scanLog->distance_m !== null ? number_format($f->scanLog->distance_m).' m' : '—'); ?>

                                        <?php if($f->scanLog->accuracy !== null): ?><div class="text-xs text-slate-500">±<?php echo e(number_format($f->scanLog->accuracy)); ?> m</div><?php endif; ?>
                                    </td>
                                    <td class="font-mono text-xs"><?php echo e($f->scanLog->ip ?? '—'); ?></td>
                                    <td class="whitespace-nowrap"><?php echo e($f->scanLog->scanned_at->format('g:i:s A')); ?></td>
                                    <td class="text-right whitespace-nowrap">
                                        <?php if($f->isCleared()): ?>
                                            <span class="text-xs text-slate-500">Cleared by <?php echo e($f->clearedBy?->name ?? 'teacher'); ?><br><?php echo e($f->cleared_at->format('M j, g:i A')); ?></span>
                                        <?php else: ?>
                                            <form method="POST" action="<?php echo e(route('flags.clear', $f)); ?>"><?php echo csrf_field(); ?><button class="btn-secondary btn-sm">Clear</button></form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="7" class="py-6 text-center text-slate-500">No flagged scans.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <form method="POST" action="<?php echo e(route('sessions.update', $session)); ?>" class="card h-fit space-y-4" novalidate>
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <h2 class="h2">Session settings</h2>
            <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'title','label' => 'Title','value' => $session->title,'placeholder' => 'Optional']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'title','label' => 'Title','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($session->title),'placeholder' => 'Optional']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'grace_minutes','label' => 'Grace period (minutes)','type' => 'number','min' => '0','value' => $session->grace_minutes,'required' => true,'help' => 'Changing this recalculates Present/Late for QR Time In scans (not manual entries).']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grace_minutes','label' => 'Grace period (minutes)','type' => 'number','min' => '0','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($session->grace_minutes),'required' => true,'help' => 'Changing this recalculates Present/Late for QR Time In scans (not manual entries).']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
            <button class="btn-primary w-full">Save</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/sessions/show.blade.php ENDPATH**/ ?>