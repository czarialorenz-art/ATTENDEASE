<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Attendance report – <?php echo e($class->subject); ?></title>
    <style>
        @page { margin: 14mm 14mm; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 9.5pt; color: #111; }
        h1 { text-align: center; font-size: 14pt; margin: 0; }
        h2 { text-align: center; font-size: 11pt; margin: 2px 0 10px; font-weight: normal; }
        .meta td { padding: 1px 10px 1px 0; }
        .meta .k { font-weight: bold; }
        table.data { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table.data th, table.data td { border: 1px solid #888; padding: 4px 6px; }
        table.data th { background: #e5e7eb; text-align: left; }
        .c { text-align: center; }
        .note { margin-top: 8px; font-style: italic; color: #444; }
    </style>
</head>
<body>
    <h1><?php echo e($schoolName); ?></h1>
    <h2><?php echo e($title); ?></h2>

    <table class="meta">
        <?php $__currentLoopData = array_chunk($header, 3, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td class="k"><?php echo e($k); ?>:</td><td><?php echo e($v); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <table class="data">
        <thead><tr><th>#</th><th>Student No.</th><th>Name</th><th>Section</th><th class="c">Present</th><th class="c">Late</th><th class="c">Absent</th><th class="c">Rate</th></tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($r['student']->id_number); ?></td>
                    <td><?php echo e($r['student']->name); ?><?php echo e($r['removed'] ? ' (removed)' : ''); ?></td>
                    <td><?php echo e($r['student']->section ?: '—'); ?></td>
                    <td class="c"><?php echo e($r['present']); ?></td>
                    <td class="c"><?php echo e($r['late']); ?></td>
                    <td class="c"><?php echo e($r['absent']); ?></td>
                    <td class="c"><?php echo e($r['rate'] === null ? '—' : $r['rate'].'%'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="c">No students.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="note">Sessions held in this period: <?php echo e($held); ?></div>
</body>
</html>
<?php /**PATH C:\MTQ APP\attendease\resources\views/pdf/attendance-report.blade.php ENDPATH**/ ?>