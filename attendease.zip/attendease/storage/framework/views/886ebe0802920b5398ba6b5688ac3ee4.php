<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $class->subject.' settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->subject.' settings')]); ?>
    <?php if (isset($component)) { $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.class-nav','data' => ['class' => $class,'active' => 'schedule']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('class-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class),'active' => 'schedule']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $attributes = $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $component = $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>

    <div class="grid gap-6 lg:grid-cols-2">
        <form method="POST" action="<?php echo e(route('classes.update', $class)); ?>" class="card space-y-4" novalidate>
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <h2 class="h2">Class details</h2>
            <?php echo $__env->make('classes._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="flex justify-end"><button class="btn-primary">Save details</button></div>
        </form>

        <form method="POST" action="<?php echo e(route('classes.schedule', $class)); ?>" class="card space-y-4" novalidate>
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <h2 class="h2">Weekly schedule</h2>

            <?php
                $rows = old('schedules', $class->schedules->map(fn ($s) => [
                    'day_of_week' => $s->day_of_week, 'start_time' => substr($s->start_time, 0, 5),
                    'end_time' => substr($s->end_time, 0, 5), 'room' => $s->room,
                ])->all());
                $rows[] = ['day_of_week' => '', 'start_time' => '', 'end_time' => '', 'room' => ''];
            ?>

            <div id="schedule-rows" class="space-y-3">
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid grid-cols-2 gap-2 rounded-lg border border-slate-200 p-3 sm:grid-cols-[1.2fr_1fr_1fr_1fr]" data-row>
                        <select name="schedules[<?php echo e($i); ?>][day_of_week]" class="input col-span-2 sm:col-span-1" aria-label="Day">
                            <option value="">Day…</option>
                            <?php $__currentLoopData = \App\Models\ClassSchedule::DAYS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d); ?>" <?php if((string) ($row['day_of_week'] ?? '') === (string) $d): echo 'selected'; endif; ?>><?php echo e($name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="time" name="schedules[<?php echo e($i); ?>][start_time]" value="<?php echo e($row['start_time'] ?? ''); ?>" class="input" aria-label="Start time">
                        <input type="time" name="schedules[<?php echo e($i); ?>][end_time]" value="<?php echo e($row['end_time'] ?? ''); ?>" class="input" aria-label="End time">
                        <input name="schedules[<?php echo e($i); ?>][room]" value="<?php echo e($row['room'] ?? ''); ?>" class="input col-span-2 sm:col-span-1" placeholder="Room" aria-label="Room">
                        <?php $__currentLoopData = ['day_of_week', 'start_time', 'end_time', 'room']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__errorArgs = ["schedules.$i.$f"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="error col-span-full"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button type="button" class="btn-secondary btn-sm" id="add-row">+ Add a row</button>
            <p class="help">Leave a row blank to remove it.</p>

            <h2 class="h2 pt-2">Classroom location</h2>
            <p class="text-sm text-slate-500">Used to flag scans from too far away. Leave blank to turn the check off.</p>
            <div class="grid gap-3 sm:grid-cols-3">
                <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'latitude','label' => 'Latitude','value' => $class->latitude,'inputmode' => 'decimal','placeholder' => '14.6507']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'latitude','label' => 'Latitude','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->latitude),'inputmode' => 'decimal','placeholder' => '14.6507']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'longitude','label' => 'Longitude','value' => $class->longitude,'inputmode' => 'decimal','placeholder' => '121.0494']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'longitude','label' => 'Longitude','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->longitude),'inputmode' => 'decimal','placeholder' => '121.0494']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalae4c123bc9806121d87d234de2f27a3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalae4c123bc9806121d87d234de2f27a3b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.field','data' => ['name' => 'radius_m','label' => 'Radius (m)','type' => 'number','value' => $class->radius_m ?? 100,'min' => '10','max' => '5000']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'radius_m','label' => 'Radius (m)','type' => 'number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->radius_m ?? 100),'min' => '10','max' => '5000']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $attributes = $__attributesOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__attributesOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalae4c123bc9806121d87d234de2f27a3b)): ?>
<?php $component = $__componentOriginalae4c123bc9806121d87d234de2f27a3b; ?>
<?php unset($__componentOriginalae4c123bc9806121d87d234de2f27a3b); ?>
<?php endif; ?>
            </div>
            <button type="button" class="btn-secondary btn-sm" id="use-location">Use my current location</button>
            <p id="loc-msg" class="help"></p>

            <div class="flex justify-end"><button class="btn-primary">Save schedule & location</button></div>
        </form>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.getElementById('add-row').addEventListener('click', () => {
            const wrap = document.getElementById('schedule-rows');
            const last = wrap.querySelector('[data-row]:last-child');
            const clone = last.cloneNode(true);
            const n = wrap.querySelectorAll('[data-row]').length;
            clone.querySelectorAll('[name]').forEach(el => { el.name = el.name.replace(/schedules\[\d+]/, `schedules[${n}]`); el.value = ''; });
            clone.querySelectorAll('.error').forEach(el => el.remove());
            wrap.appendChild(clone);
        });
        document.getElementById('use-location').addEventListener('click', () => {
            const msg = document.getElementById('loc-msg');
            if (!navigator.geolocation) { msg.textContent = 'This browser has no location support.'; return; }
            msg.textContent = 'Getting your location…';
            navigator.geolocation.getCurrentPosition(p => {
                document.getElementById('f_latitude').value = p.coords.latitude.toFixed(7);
                document.getElementById('f_longitude').value = p.coords.longitude.toFixed(7);
                msg.textContent = `Accuracy about ${Math.round(p.coords.accuracy)} m. Save to keep it.`;
            }, e => { msg.textContent = 'Could not get location: ' + e.message; }, { enableHighAccuracy: true, timeout: 10000 });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/classes/edit.blade.php ENDPATH**/ ?>