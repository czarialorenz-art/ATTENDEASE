<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $class->subject.' students']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class->subject.' students')]); ?>
    <?php if (isset($component)) { $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.class-nav','data' => ['class' => $class,'active' => 'students']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('class-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class),'active' => 'students']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $attributes = $__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__attributesOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6)): ?>
<?php $component = $__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6; ?>
<?php unset($__componentOriginalc84119ef5052e58c06cf4fbb491fb1a6); ?>
<?php endif; ?>

    <div class="grid gap-6 lg:grid-cols-2">
        <section class="card">
            <h2 class="h2 mb-3">Join requests <span class="badge-pending ml-1"><?php echo e($pending->count()); ?></span></h2>
            <?php $__empty_1 = true; $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 py-2.5 first:border-0">
                    <div>
                        <div class="flex flex-wrap items-center gap-1.5 font-medium">
                            <?php echo e($e->student->name); ?>

                            <?php echo $__env->make('classes._section-badge', ['student' => $e->student], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                        <div class="text-xs text-slate-500"><?php echo e($e->student->id_number); ?> · <?php echo e($e->student->email); ?> · <?php echo e($e->updated_at->diffForHumans()); ?></div>
                    </div>
                    <div class="flex gap-2">
                        <form method="POST" action="<?php echo e(route('enrollments.approve', $e)); ?>"><?php echo csrf_field(); ?><button class="btn-success btn-sm">Approve</button></form>
                        <form method="POST" action="<?php echo e(route('enrollments.reject', $e)); ?>"><?php echo csrf_field(); ?><button class="btn-secondary btn-sm">Reject</button></form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">No pending requests. Share the code <span class="font-mono font-semibold"><?php echo e($class->code); ?></span> with your students.</p>
            <?php endif; ?>
        </section>

        <section class="card">
            <h2 class="h2 mb-3">Enrolled students <span class="badge-neutral ml-1"><?php echo e($approved->count()); ?></span></h2>
            <?php $__empty_1 = true; $__currentLoopData = $approved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between gap-2 border-t border-slate-100 py-2.5 first:border-0">
                    <div>
                        <div class="flex flex-wrap items-center gap-1.5 font-medium">
                            <?php echo e($e->student->name); ?>

                            <?php echo $__env->make('classes._section-badge', ['student' => $e->student], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                        <div class="text-xs text-slate-500"><?php echo e($e->student->id_number); ?> · <?php echo e($e->student->email); ?></div>
                    </div>
                    <form method="POST" action="<?php echo e(route('enrollments.remove', $e)); ?>" data-confirm="Remove <?php echo e($e->student->name); ?> from this class? Their past records are kept.">
                        <?php echo csrf_field(); ?><button class="btn-secondary btn-sm text-red-600">Remove</button>
                    </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">No students yet.</p>
            <?php endif; ?>

            <?php if($removed->isNotEmpty()): ?>
                <h3 class="mt-5 mb-1 text-sm font-semibold text-slate-600">Removed</h3>
                <?php $__currentLoopData = $removed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-sm text-slate-500"><?php echo e($e->student->name); ?> · <?php echo e($e->student->id_number); ?><?php echo e(filled($e->student->section) ? ' · Section '.$e->student->section : ''); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\MTQ APP\attendease\resources\views/classes/students.blade.php ENDPATH**/ ?>