<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class', 'active']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class', 'active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $tabs = [
        'overview' => ['Overview', route('classes.show', $class)],
        'students' => ['Students', route('classes.students', $class)],
        'schedule' => ['Schedule & location', route('classes.edit', $class)],
        'sessions' => ['Sessions', route('sessions.index', $class)],
        'report' => ['Report', route('reports.show', $class)],
    ];
?>

<div class="mb-5">
    <div class="mb-3 flex flex-wrap items-baseline gap-x-3 gap-y-1">
        <h1 class="h1"><?php echo e($class->subject); ?> <span class="font-medium text-slate-500">· <?php echo e($class->section); ?></span></h1>
        <span class="text-sm text-slate-500"><?php echo e($class->year_level); ?> · <?php echo e($class->school_term); ?> · <?php echo e($class->semester); ?> sem</span>
    </div>
    <nav class="-mx-4 flex gap-1 overflow-x-auto px-4 pb-1">
        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => [$label, $url]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($url); ?>" class="<?php echo e($active === $key ? 'tab-active' : 'tab'); ?>"><?php echo e($label); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
</div>
<?php /**PATH C:\MTQ APP\attendease\resources\views/components/class-nav.blade.php ENDPATH**/ ?>