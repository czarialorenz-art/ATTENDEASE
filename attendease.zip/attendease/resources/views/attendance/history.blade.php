<x-layouts.app title="My attendance">
    <h1 class="h1 mb-4">My attendance</h1>

    <form method="GET" class="card mb-5 grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
        <div>
            <label class="label" for="class_id">Class</label>
            <select id="class_id" name="class_id" class="input">
                <option value="">All classes</option>
                @foreach ($classes as $c)
                    <option value="{{ $c->id }}" @selected((string) request('class_id') === (string) $c->id)>{{ $c->label() }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="label" for="term">School term</label>
            <select id="term" name="term" class="input">
                <option value="">All terms</option>
                @foreach ($terms as $t)
                    <option value="{{ $t }}" @selected(request('term') === $t)>{{ $t }}</option>
                @endforeach
            </select>
        </div>
        <button class="btn-primary">Filter</button>
    </form>

    <div class="card">
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>Date</th><th>Class</th><th>Status</th><th>Time In</th><th>Time Out</th></tr></thead>
                <tbody>
                    @forelse ($records as $r)
                        <tr>
                            <td class="whitespace-nowrap">{{ $r->attendanceSession->date->format('D, M j, Y') }}</td>
                            <td>{{ $r->attendanceSession->schoolClass->label() }}@if ($r->attendanceSession->title)<div class="text-xs text-slate-500">{{ $r->attendanceSession->title }}</div>@endif</td>
                            <td><span class="badge-{{ $r->status }}">{{ ucfirst($r->status) }}</span></td>
                            <td class="whitespace-nowrap">{{ $r->time_in_at?->format('g:i A') ?? '—' }}</td>
                            <td class="whitespace-nowrap">{{ $r->time_out_at?->format('g:i A') ?? '—' }}</td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="py-6 text-center text-slate-500">No attendance records yet.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</x-layouts.app>
