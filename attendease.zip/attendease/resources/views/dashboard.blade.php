<x-layouts.app title="Dashboard">
    <div class="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
            <h1 class="h1">Hi, {{ \Illuminate\Support\Str::before(auth()->user()->name, ' ') ?: auth()->user()->name }}</h1>
            <p class="text-sm text-slate-500">{{ now()->format('l, F j, Y') }}</p>
        </div>
        <a href="{{ route('classes.create') }}" class="btn-primary">+ Create a class</a>
    </div>

    {{-- Join a class (FR-CLS-04) --}}
    <form method="POST" action="{{ route('classes.join') }}" class="card mb-6 flex flex-col gap-3 sm:flex-row sm:items-end" novalidate>
        @csrf
        <div class="flex-1">
            <label for="code" class="label">Join a class</label>
            <input id="code" name="code" value="{{ old('code') }}" maxlength="8" autocapitalize="characters" autocomplete="off"
                placeholder="Enter class code" @class(['input font-mono tracking-widest uppercase', 'input-error' => $errors->has('code')])>
            @error('code')<p class="error">{{ $message }}</p>@enderror
        </div>
        <button class="btn-primary sm:w-40">Ask to join</button>
    </form>

    <div class="grid gap-6 lg:grid-cols-2">
        {{-- Teaching side --}}
        <section class="space-y-6">
            @if ($todaySessions->isNotEmpty())
                <div class="card">
                    <h2 class="h2 mb-3">Today's sessions</h2>
                    <ul class="divide-y divide-slate-100">
                        @foreach ($todaySessions as $s)
                            <li class="flex items-center justify-between gap-3 py-2">
                                <div class="min-w-0">
                                    <div class="truncate font-medium">{{ $s->schoolClass->label() }}</div>
                                    <div class="text-xs text-slate-500">{{ $s->title ?: 'Attendance' }} ·
                                        @if ($s->openStage()) <span class="font-semibold text-emerald-700">{{ \App\Models\AttendanceSession::stageLabel($s->openStage()) }} open</span>
                                        @elseif ($s->time_out_closed_at) Completed
                                        @else Not started @endif
                                    </div>
                                </div>
                                <a href="{{ $s->openStage() ? route('sessions.live', $s) : route('sessions.show', $s) }}" class="btn-secondary btn-sm">{{ $s->openStage() ? 'Show QR' : 'Open' }}</a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card">
                <h2 class="h2 mb-3">Classes I teach</h2>
                @forelse ($teaching as $c)
                    <a href="{{ route('classes.show', $c) }}" class="-mx-2 flex items-center justify-between gap-3 rounded-lg px-2 py-2.5 hover:bg-slate-50">
                        <div class="min-w-0">
                            <div class="truncate font-medium">{{ $c->subject }} · {{ $c->section }}</div>
                            <div class="text-xs text-slate-500">{{ $c->school_term }} · {{ $c->semester }} sem · {{ $c->student_count }} {{ \Illuminate\Support\Str::plural('student', $c->student_count) }} · code <span class="font-mono">{{ $c->code }}</span></div>
                        </div>
                        @if ($c->pending_count)
                            <span class="badge-pending shrink-0">{{ $c->pending_count }} pending</span>
                        @endif
                    </a>
                @empty
                    <p class="text-sm text-slate-500">You don't teach any classes yet. Create one to get a join code for your students.</p>
                @endforelse
            </div>
        </section>

        {{-- Student side --}}
        <section class="space-y-6">
            @if ($enrolled->where('status', 'approved')->isNotEmpty())
                <a href="{{ route('scanner') }}" class="card flex items-center gap-4 border-brand-100 bg-brand-50 hover:bg-brand-100">
                    <span class="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-brand-600 text-white">
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 7V5a1 1 0 011-1h2M17 4h2a1 1 0 011 1v2M20 17v2a1 1 0 01-1 1h-2M7 20H5a1 1 0 01-1-1v-2M8 8h3v3H8zM13 13h3v3h-3zM13 8h3M8 13v3"/></svg>
                    </span>
                    <span>
                        <span class="block font-semibold text-brand-800">Scan attendance QR</span>
                        <span class="block text-sm text-slate-600">Open the camera and scan the code on your teacher's screen.</span>
                    </span>
                </a>
            @endif

            <div class="card">
                <h2 class="h2 mb-3">Classes I'm in</h2>
                @forelse ($enrolled as $e)
                    @php($approved = $e->status === 'approved')
                    <{{ $approved ? 'a' : 'div' }} @if ($approved) href="{{ route('classes.show', $e->schoolClass) }}" @endif
                        @class(['-mx-2 flex items-center justify-between gap-3 rounded-lg px-2 py-2.5', 'hover:bg-slate-50' => $approved])>
                        <div class="min-w-0">
                            <div class="truncate font-medium">{{ $e->schoolClass->subject }} · {{ $e->schoolClass->section }}</div>
                            <div class="text-xs text-slate-500">{{ $e->schoolClass->teacher->name }} · {{ $e->schoolClass->school_term }}</div>
                        </div>
                        @unless ($approved)<span class="badge-pending shrink-0">Waiting for approval</span>@endunless
                    </{{ $approved ? 'a' : 'div' }}>
                @empty
                    <p class="text-sm text-slate-500">You haven't joined any classes. Enter the code your teacher gives you above.</p>
                @endforelse
            </div>
        </section>
    </div>
</x-layouts.app>
