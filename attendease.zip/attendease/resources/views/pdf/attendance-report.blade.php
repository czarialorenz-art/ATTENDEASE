<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Attendance report – {{ $class->subject }}</title>
    <style>
        @page { margin: 14mm 14mm; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 9.5pt; color: #111; }
        h1 { text-align: center; font-size: 14pt; margin: 0; }
        h2 { text-align: center; font-size: 11pt; margin: 2px 0 10px; font-weight: normal; }
        .meta td { padding: 1px 10px 1px 0; }
        .meta .k { font-weight: bold; }
        table.data { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table.data th, table.data td { border: 1px solid #888; padding: 4px 6px; }
        table.data th { background: #e5e7eb; text-align: left; }
        .c { text-align: center; }
        .note { margin-top: 8px; font-style: italic; color: #444; }
    </style>
</head>
<body>
    <h1>{{ $schoolName }}</h1>
    <h2>{{ $title }}</h2>

    <table class="meta">
        @foreach (array_chunk($header, 3, true) as $chunk)
            <tr>@foreach ($chunk as $k => $v)<td class="k">{{ $k }}:</td><td>{{ $v }}</td>@endforeach</tr>
        @endforeach
    </table>

    <table class="data">
        <thead><tr><th>#</th><th>Student No.</th><th>Name</th><th>Section</th><th class="c">Present</th><th class="c">Late</th><th class="c">Absent</th><th class="c">Rate</th></tr></thead>
        <tbody>
            @forelse ($rows as $i => $r)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>{{ $r['student']->id_number }}</td>
                    <td>{{ $r['student']->name }}{{ $r['removed'] ? ' (removed)' : '' }}</td>
                    <td>{{ $r['student']->section ?: '—' }}</td>
                    <td class="c">{{ $r['present'] }}</td>
                    <td class="c">{{ $r['late'] }}</td>
                    <td class="c">{{ $r['absent'] }}</td>
                    <td class="c">{{ $r['rate'] === null ? '—' : $r['rate'].'%' }}</td>
                </tr>
            @empty
                <tr><td colspan="8" class="c">No students.</td></tr>
            @endforelse
        </tbody>
    </table>
    <div class="note">Sessions held in this period: {{ $held }}</div>
</body>
</html>
