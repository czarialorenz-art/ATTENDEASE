<x-layouts.app :title="$class->subject.' sessions'">
    <x-class-nav :class="$class" active="sessions" />

    <div class="grid gap-6 lg:grid-cols-3">
        <form method="POST" action="{{ route('sessions.store', $class) }}" class="card space-y-4 lg:col-span-1" novalidate>
            @csrf
            <h2 class="h2">New session</h2>
            <x-field name="date" label="Date" type="date" :value="now()->toDateString()" required help="Stages can only be opened on this date." />
            <x-field name="title" label="Title" placeholder="Optional, e.g. Week 5 lecture" />
            <x-field name="grace_minutes" label="Grace period (minutes)" type="number" :value="15" min="0" help="Scans within this time after Time In opens are Present; later ones are Late." />
            <button class="btn-primary w-full">Create session</button>
        </form>

        <div class="card lg:col-span-2">
            <h2 class="h2 mb-3">Sessions</h2>
            <div class="table-wrap">
                <table class="table">
                    <thead><tr><th>Date</th><th>Title</th><th>Grace</th><th>Status</th><th>Records</th><th></th></tr></thead>
                    <tbody>
                        @forelse ($sessions as $s)
                            <tr>
                                <td class="whitespace-nowrap">{{ $s->date->format('D, M j, Y') }}</td>
                                <td>{{ $s->title ?: '—' }}</td>
                                <td>{{ $s->grace_minutes }} min</td>
                                <td class="whitespace-nowrap">
                                    @if ($s->openStage()) <span class="badge-approved">{{ \App\Models\AttendanceSession::stageLabel($s->openStage()) }} open</span>
                                    @elseif ($s->time_out_closed_at) <span class="badge-neutral">Completed</span>
                                    @elseif ($s->time_in_opened_at) <span class="badge-pending">In progress</span>
                                    @else <span class="text-slate-400">Not started</span> @endif
                                </td>
                                <td>{{ $s->records_count }}</td>
                                <td class="text-right"><a href="{{ route('sessions.show', $s) }}" class="btn-secondary btn-sm">Open</a></td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="py-6 text-center text-slate-500">No sessions yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="mt-4">{{ $sessions->links() }}</div>
        </div>
    </div>
</x-layouts.app>
