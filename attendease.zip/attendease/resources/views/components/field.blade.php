@props(['name', 'label', 'type' => 'text', 'value' => null, 'help' => null, 'required' => false])

@php($id = 'f_'.str_replace(['[', ']', '.'], '_', $name))
<div {{ $attributes->only('class') }}>
    <label for="{{ $id }}" class="label">{{ $label }}@if ($required) <span class="text-red-600">*</span>@endif</label>
    @if ($type === 'select')
        <select id="{{ $id }}" name="{{ $name }}" @class(['input', 'input-error' => $errors->has($name)]) {{ $attributes->except('class') }} @required($required)>
            {{ $slot }}
        </select>
    @elseif ($type === 'textarea')
        <textarea id="{{ $id }}" name="{{ $name }}" @class(['input', 'input-error' => $errors->has($name)]) {{ $attributes->except('class') }} @required($required)>{{ old($name, $value) }}</textarea>
    @else
        <input id="{{ $id }}" name="{{ $name }}" type="{{ $type }}"
            @if ($type !== 'password' && $type !== 'file') value="{{ old($name, $value) }}" @endif
            @class(['input', 'input-error' => $errors->has($name)]) {{ $attributes->except('class') }} @required($required)>
    @endif
    @if ($help)<p class="help">{{ $help }}</p>@endif
    @error($name)<p class="error">{{ $message }}</p>@enderror
</div>
