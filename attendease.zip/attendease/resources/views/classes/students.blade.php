<x-layouts.app :title="$class->subject.' students'">
    <x-class-nav :class="$class" active="students" />

    <div class="grid gap-6 lg:grid-cols-2">
        <section class="card">
            <h2 class="h2 mb-3">Join requests <span class="badge-pending ml-1">{{ $pending->count() }}</span></h2>
            @forelse ($pending as $e)
                <div class="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 py-2.5 first:border-0">
                    <div>
                        <div class="flex flex-wrap items-center gap-1.5 font-medium">
                            {{ $e->student->name }}
                            @include('classes._section-badge', ['student' => $e->student])
                        </div>
                        <div class="text-xs text-slate-500">{{ $e->student->id_number }} · {{ $e->student->email }} · {{ $e->updated_at->diffForHumans() }}</div>
                    </div>
                    <div class="flex gap-2">
                        <form method="POST" action="{{ route('enrollments.approve', $e) }}">@csrf<button class="btn-success btn-sm">Approve</button></form>
                        <form method="POST" action="{{ route('enrollments.reject', $e) }}">@csrf<button class="btn-secondary btn-sm">Reject</button></form>
                    </div>
                </div>
            @empty
                <p class="text-sm text-slate-500">No pending requests. Share the code <span class="font-mono font-semibold">{{ $class->code }}</span> with your students.</p>
            @endforelse
        </section>

        <section class="card">
            <h2 class="h2 mb-3">Enrolled students <span class="badge-neutral ml-1">{{ $approved->count() }}</span></h2>
            @forelse ($approved as $e)
                <div class="flex items-center justify-between gap-2 border-t border-slate-100 py-2.5 first:border-0">
                    <div>
                        <div class="flex flex-wrap items-center gap-1.5 font-medium">
                            {{ $e->student->name }}
                            @include('classes._section-badge', ['student' => $e->student])
                        </div>
                        <div class="text-xs text-slate-500">{{ $e->student->id_number }} · {{ $e->student->email }}</div>
                    </div>
                    <form method="POST" action="{{ route('enrollments.remove', $e) }}" data-confirm="Remove {{ $e->student->name }} from this class? Their past records are kept.">
                        @csrf<button class="btn-secondary btn-sm text-red-600">Remove</button>
                    </form>
                </div>
            @empty
                <p class="text-sm text-slate-500">No students yet.</p>
            @endforelse

            @if ($removed->isNotEmpty())
                <h3 class="mt-5 mb-1 text-sm font-semibold text-slate-600">Removed</h3>
                @foreach ($removed as $e)
                    <div class="text-sm text-slate-500">{{ $e->student->name }} · {{ $e->student->id_number }}{{ filled($e->student->section) ? ' · Section '.$e->student->section : '' }}</div>
                @endforeach
            @endif
        </section>
    </div>
</x-layouts.app>
