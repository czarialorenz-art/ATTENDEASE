<?php

namespace Tests\Feature;

use App\Models\AttendanceRecord;
use App\Models\AttendanceSession;
use App\Models\Enrollment;
use App\Models\SchoolClass;
use App\Models\User;
use App\Notifications\JoinRequestDecided;
use App\Notifications\JoinRequestReceived;
use App\Notifications\RemovedFromClass;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Notification;
use Tests\TestCase;

class ClassEnrollmentTest extends TestCase
{
    use RefreshDatabase;

    private function classData(array $overrides = []): array
    {
        return array_merge([
            'subject' => 'ITE101', 'year_level' => '1st Year', 'section' => 'BSIT-1A',
            'school_term' => '2026-2027', 'semester' => '1st',
            'semester_start' => '2026-08-01', 'semester_end' => '2026-12-15',
        ], $overrides);
    }

    public function test_fr_cls_01_teacher_creates_class_and_becomes_its_teacher(): void
    {
        $teacher = User::factory()->create();

        $this->actingAs($teacher)->post('/classes', $this->classData())->assertRedirect();

        $class = SchoolClass::first();
        $this->assertSame($teacher->id, $class->teacher_id);
        $this->assertSame('ITE101', $class->subject);
    }

    public function test_fr_cls_01_validation(): void
    {
        $teacher = User::factory()->create();

        $this->actingAs($teacher)->post('/classes', $this->classData(['semester_end' => '2026-07-01']))->assertSessionHasErrors('semester_end');
        $this->actingAs($teacher)->post('/classes', $this->classData(['semester' => '3rd']))->assertSessionHasErrors('semester');
        $this->actingAs($teacher)->post('/classes', $this->classData(['subject' => '']))->assertSessionHasErrors('subject');
        $this->assertDatabaseCount('classes', 0);
    }

    public function test_fr_cls_02_code_is_unique_6_to_8_chars_without_lookalikes(): void
    {
        $codes = collect(range(1, 40))->map(fn () => $this->makeClass()->code);

        $this->assertSame($codes->count(), $codes->unique()->count());
        foreach ($codes as $code) {
            $this->assertMatchesRegularExpression('/^[A-HJ-NP-Z2-9]{6,8}$/', $code);
        }

        $class = $this->makeClass();
        $this->actingAs($class->teacher)->get("/classes/{$class->id}")->assertSee($class->code)->assertSee('data-copy', false);
    }

    public function test_fr_cls_03_edit_class_schedule_and_location(): void
    {
        $class = $this->makeClass();

        $this->actingAs($class->teacher)->put("/classes/{$class->id}", $this->classData(['section' => 'B']))->assertSessionHasNoErrors();
        $this->assertSame('B', $class->fresh()->section);

        $this->actingAs($class->teacher)->put("/classes/{$class->id}/schedule", [
            'schedules' => [
                ['day_of_week' => 1, 'start_time' => '08:00', 'end_time' => '09:30', 'room' => 'R201'],
                ['day_of_week' => 3, 'start_time' => '13:00', 'end_time' => '14:30', 'room' => ''],
                ['day_of_week' => '', 'start_time' => '', 'end_time' => '', 'room' => ''], // blank row ignored
            ],
            'latitude' => '14.6507', 'longitude' => '121.0494', 'radius_m' => '',
        ])->assertSessionHasNoErrors();

        $class->refresh();
        $this->assertCount(2, $class->schedules);
        $this->assertEqualsWithDelta(14.6507, $class->latitude, 0.00001);
        $this->assertSame(100, $class->radius_m); // default

        $this->actingAs($class->teacher)->put("/classes/{$class->id}/schedule", [
            'schedules' => [['day_of_week' => 1, 'start_time' => '10:00', 'end_time' => '09:00']],
        ])->assertSessionHasErrors('schedules.0.end_time');
    }

    public function test_fr_cls_04_join_by_code_creates_pending_request(): void
    {
        Notification::fake();
        $class = $this->makeClass();
        $student = User::factory()->create();

        $this->actingAs($student)->post('/classes/join', ['code' => strtolower($class->code)])->assertSessionHasNoErrors();

        $this->assertDatabaseHas('enrollments', ['class_id' => $class->id, 'student_id' => $student->id, 'status' => 'pending']);
    }

    public function test_fr_cls_04_wrong_code_duplicate_already_in_and_own_class_are_rejected(): void
    {
        Notification::fake();
        $class = $this->makeClass();
        $student = User::factory()->create();

        $this->actingAs($student)->post('/classes/join', ['code' => 'ZZZZZZZ'])->assertSessionHasErrors('code');

        $this->actingAs($student)->post('/classes/join', ['code' => $class->code]);
        $this->actingAs($student)->post('/classes/join', ['code' => $class->code])->assertSessionHasErrors('code');

        Enrollment::where('student_id', $student->id)->update(['status' => 'approved']);
        $this->actingAs($student)->post('/classes/join', ['code' => $class->code])->assertSessionHasErrors('code');

        $this->actingAs($class->teacher)->post('/classes/join', ['code' => $class->code])->assertSessionHasErrors('code');
        $this->assertDatabaseCount('enrollments', 1);
    }

    public function test_fr_cls_05_teacher_approves_or_rejects_and_rejected_may_ask_again(): void
    {
        Notification::fake();
        $class = $this->makeClass();
        $a = $this->enroll($class, null, Enrollment::PENDING);
        $b = $this->enroll($class, null, Enrollment::PENDING);
        $ea = Enrollment::where('student_id', $a->id)->first();
        $eb = Enrollment::where('student_id', $b->id)->first();

        $this->actingAs($class->teacher)->get("/classes/{$class->id}/students")->assertSee($a->name)->assertSee($b->name);
        $this->actingAs($class->teacher)->post("/enrollments/{$ea->id}/approve");
        $this->actingAs($class->teacher)->post("/enrollments/{$eb->id}/reject");

        $this->assertSame('approved', $ea->fresh()->status);
        $this->assertNotNull($ea->fresh()->decided_at);
        $this->assertSame('rejected', $eb->fresh()->status);

        $this->actingAs($b)->post('/classes/join', ['code' => $class->code])->assertSessionHasNoErrors();
        $this->assertSame('pending', $eb->fresh()->status);
    }

    public function test_students_page_shows_each_students_section(): void
    {
        $class = $this->makeClass();
        $this->enroll($class, User::factory()->create(['name' => 'Ana Cruz', 'section' => 'BSIT-2A']));
        $this->enroll($class, User::factory()->create(['name' => 'Ben Lim', 'section' => null]));
        $this->enroll($class, User::factory()->create(['name' => 'Cara Uy', 'section' => 'BSIT-2C']), Enrollment::PENDING);

        $this->actingAs($class->teacher)->get("/classes/{$class->id}/students")->assertOk()
            ->assertSeeInOrder(['Ana Cruz', 'Section BSIT-2A'])
            ->assertSeeInOrder(['Ben Lim', 'No section'])
            ->assertSeeInOrder(['Cara Uy', 'Section BSIT-2C']); // join requests show it too
    }

    public function test_fr_cls_06_removed_student_loses_access_but_records_are_kept(): void
    {
        Notification::fake();
        $class = $this->makeClass();
        $student = $this->enroll($class);
        $session = AttendanceSession::factory()->for($class, 'schoolClass')->create();
        AttendanceRecord::factory()->create(['attendance_session_id' => $session->id, 'student_id' => $student->id]);
        $enrollment = Enrollment::where('student_id', $student->id)->first();

        $this->actingAs($class->teacher)->post("/enrollments/{$enrollment->id}/remove");

        $this->assertSame('removed', $enrollment->fresh()->status);
        $this->actingAs($student)->get("/classes/{$class->id}")->assertForbidden();
        $this->assertDatabaseCount('attendance_records', 1);
    }

    public function test_fr_cls_07_each_step_notifies_the_other_side(): void
    {
        Notification::fake();
        $class = $this->makeClass();
        $student = User::factory()->create();

        $this->actingAs($student)->post('/classes/join', ['code' => $class->code]);
        Notification::assertSentTo($class->teacher, JoinRequestReceived::class);

        $e = Enrollment::first();
        $this->actingAs($class->teacher)->post("/enrollments/{$e->id}/approve");
        Notification::assertSentTo($student, JoinRequestDecided::class, fn ($n) => $n->enrollment->status === 'approved');

        $this->actingAs($class->teacher)->post("/enrollments/{$e->id}/remove");
        Notification::assertSentTo($student, RemovedFromClass::class);

        $this->actingAs($student)->post('/classes/join', ['code' => $class->code]);
        $this->actingAs($class->teacher)->post("/enrollments/{$e->id}/reject");
        Notification::assertSentTo($student, JoinRequestDecided::class, fn ($n) => $n->enrollment->status === 'rejected');
    }

    public function test_fr_cls_08_dashboard_lists_taught_and_joined_classes(): void
    {
        $me = User::factory()->create();
        $mine = $this->makeClass($me, ['subject' => 'TAUGHT1']);
        $this->enroll($mine, null, Enrollment::PENDING);
        $this->enroll($mine, null, Enrollment::PENDING);
        $joined = $this->makeClass(null, ['subject' => 'JOINED1']);
        $this->enroll($joined, $me);
        $waiting = $this->makeClass(null, ['subject' => 'WAITING1']);
        $this->enroll($waiting, $me, Enrollment::PENDING);
        $this->makeClass(null, ['subject' => 'OTHER1']);

        $this->actingAs($me)->get('/dashboard')->assertOk()
            ->assertSee('Classes I teach')->assertSee('TAUGHT1')->assertSee('2 pending')
            ->assertSee("Classes I'm in", false)->assertSee('JOINED1')->assertSee('WAITING1')->assertSee('Waiting for approval')
            ->assertDontSee('OTHER1')
            ->assertSee('name="code"', false);
    }
}
